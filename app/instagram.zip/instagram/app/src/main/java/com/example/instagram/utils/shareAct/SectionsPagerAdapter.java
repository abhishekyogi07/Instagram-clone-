package com.example.instagram.utils.shareAct;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class SectionsPagerAdapter extends FragmentPagerAdapter {
    private static final String tag ="section pager adapter";
    private final List<Fragment> mfragmentlist=new ArrayList<Fragment> ();



    public SectionsPagerAdapter(FragmentManager fm) {
        super (fm);
    }

    @Override
    public Fragment getItem(int i) {
        return mfragmentlist.get (i);
    }

    @Override
    public int getCount() {
        return mfragmentlist.size ();
    }
    public void addFragmnets(Fragment fragment){
        mfragmentlist.add (fragment);
    }
}
