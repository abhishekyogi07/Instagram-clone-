package com.example.instagram.utils.homeActivity;

import android.content.Context;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.instagram.R;
import com.example.instagram.utils.navigationact;
import com.example.instagram.utils.shareAct.SectionsPagerAdapter;
import com.example.instagram.utils.universalImageLoader;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;
import com.nostra13.universalimageloader.core.ImageLoader;

import static com.example.instagram.R.*;

public class MainActivity extends AppCompatActivity {
     private static final String tag="home activity";
     private static final int act_no=0;
    private Context mcontext= MainActivity.this;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);
        Log.d("on create","Starting....");
        initimageloader ();
        setupbottomnavigationView();
        setupViewPager ();
        initimageloader ();
    }
    private void initimageloader(){
        universalImageLoader uil=new universalImageLoader (mcontext);
        ImageLoader.getInstance ().init (uil.getConfig ());
    }

    private void  setupViewPager(){
        SectionsPagerAdapter adapter=new SectionsPagerAdapter (getSupportFragmentManager ());
        adapter.addFragmnets (new cameraFragment ());
        adapter.addFragmnets (new messageFragment ());
        adapter.addFragmnets (new HomeFragment ());
        ViewPager viewPager=(ViewPager)findViewById (R.id.container);
        viewPager.setAdapter (adapter);
        TabLayout tabLayout=findViewById (id.tabs);
        tabLayout.setupWithViewPager (viewPager);
    }

   private  void setupbottomnavigationView(){
        Log.d(tag,"setting up bottom nav view" );
       BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottom);
       navigationact.setupbottomnavigationView (bottomNavigationViewEx);
       navigationact.enableNavigation( mcontext,bottomNavigationViewEx);
       Menu menu=bottomNavigationViewEx.getMenu();
       MenuItem menuItem=menu.getItem(act_no);
       menuItem.setChecked(true);


   }
}
